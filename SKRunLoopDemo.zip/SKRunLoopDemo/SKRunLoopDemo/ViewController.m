//
//  ViewController.m
//  SKRunLoopDemo
//
//  Created by ios on 2021/9/15.
//

#import "ViewController.h"
#import "SKRunLoop.h"

@interface ViewController () <SKRunLoopDelegate>

/* runloop */
@property (nonatomic, strong) SKRunLoop * runLoop;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.runLoop.delegate = self;
    
    // 在需要的时候，唤醒runloop，比如：当socket 1s推送一次数据并刷新界面，socket回调方法里面可添加
    [self.runLoop startObserverRefWithTag:1];
}
#pragma mark - runLoop回调
-(void)ResultObserverRefTag:(NSInteger)tag{
    
    if (tag == 1) {
        //处理事件
    }
}
//也可使用单例方法
-(SKRunLoop *)runLoop{
    if (!_runLoop) {
        _runLoop = [[SKRunLoop alloc] init];
    }
    return  _runLoop;
}

@end
