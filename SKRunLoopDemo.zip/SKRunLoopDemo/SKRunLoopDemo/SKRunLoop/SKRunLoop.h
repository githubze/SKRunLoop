//
//  SKRunLoop.h
//  digitalCurrency
//
//  Created by ios on 2021/3/8.
//  Copyright © 2021 BitFx. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SKRunLoopDelegate <NSObject>
@optional

-(void)ResultObserverRefTag:(NSInteger)tag;

@end

@interface SKRunLoop : NSObject

/* runLoop观察者 */
@property (nonatomic, assign) CFRunLoopObserverRef observerRef;

/* 是否需要刷新列表 */
@property (nonatomic, assign) BOOL isNeedToRefreshDataList;

/* 启动者 */
@property (nonatomic, assign) NSInteger tag;


/* 代理 */
@property (nonatomic, weak) id<SKRunLoopDelegate> delegate;

+ (instancetype)instance;

/* 启动 */
- (void)startObserverRefWithTag:(NSInteger)tag;

/* 停止 */
-(void)stopObserverRefWithTag:(NSInteger)tag;

/* 关闭 */
-(void)removeObserverRef;

@end

NS_ASSUME_NONNULL_END
