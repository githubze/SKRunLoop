//
//  SKRunLoop.m
//  digitalCurrency
//
//  Created by ios on 2021/3/8.
//  Copyright © 2021 BitFx. All rights reserved.
//

#import "SKRunLoop.h"

@implementation SKRunLoop

+ (instancetype)instance
{
    static dispatch_once_t predicate;
    static id sharedInstance;
    dispatch_once(&predicate, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init
{
    if (self = [super init]) {
        
        [self runloopObserver];
        
    }
    return self;
}

#pragma mark - runLoop监听空闲刷新数据
-(void)runloopObserver{
    MJWeakSelf;

    __block NSTimeInterval timeInterVal = [[NSDate date] timeIntervalSince1970];
    
     self.observerRef = CFRunLoopObserverCreateWithHandler(CFAllocatorGetDefault(), kCFRunLoopAllActivities, YES, 0, ^(CFRunLoopObserverRef observer, CFRunLoopActivity activity) {
            if (activity == kCFRunLoopBeforeWaiting) { // runloop空闲的时候刷新需要处理的列表

                // 控制刷新频率
                NSTimeInterval currentTimeInterval = [[NSDate date] timeIntervalSince1970];
                if (currentTimeInterval - timeInterVal < 0.1) {
                    return;
                }

                timeInterVal = currentTimeInterval;
//                NSLog(@"刷新列表")
                if (weakSelf.isNeedToRefreshDataList) { // 判断是否需要刷新
                    ;
                    
                    [self.delegate ResultObserverRefTag:self.tag];
                    
                    // 标记刷新完毕,无需重复刷新
                    weakSelf.isNeedToRefreshDataList = NO;
                }
            }
        });
    
    //添加监听
    CFRunLoopAddObserver(CFRunLoopGetCurrent(), self.observerRef, kCFRunLoopDefaultMode);
}

// 刷新列表的通知方法
- (void)startObserverRefWithTag:(NSInteger)tag{
    self.tag = tag;
    
    // 标记列表需要刷新
    self.isNeedToRefreshDataList = YES;
    // 唤醒runloop
    CFRunLoopWakeUp(CFRunLoopGetMain());
}

-(void)stopObserverRefWithTag:(NSInteger)tag{
    if (tag == self.tag) {
        // 标记列表需要刷新
        self.isNeedToRefreshDataList = NO;
        CFRunLoopStop(CFRunLoopGetMain());
    }
    
}

-(void)removeObserverRef{
    //移除runloop监听
    CFRunLoopRemoveObserver(CFRunLoopGetCurrent(), self.observerRef, kCFRunLoopCommonModes);
}

@end
